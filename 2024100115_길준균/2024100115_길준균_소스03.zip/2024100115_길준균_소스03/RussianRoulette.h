#ifndef RUSSIAN_ROULETTE_H
#define RUSSIAN_ROULETTE_H
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
int playRussianRoulette(int nPlayers, int nBullets, int nChambers);
#endif