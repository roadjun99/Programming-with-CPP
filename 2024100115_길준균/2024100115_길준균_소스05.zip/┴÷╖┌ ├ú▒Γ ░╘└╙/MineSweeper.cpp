#include "MineSweeper.h"
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cctype>
using namespace std;
// ���� �Ҵ�
static int** MineMapMask = nullptr;
static int** MineMapLabel = nullptr;
static int nx = 10, ny = 10;
static int nBomb = 10;
static clock_t tStart;

enum LabalType { Empty = 0, Bomb = 9 };
enum MaskType { Hide = 0, Open, Flag };

inline int& mask(int x, int y) { return MineMapMask[y][x]; }
inline int& label(int x, int y) { return MineMapLabel[y][x]; }
inline bool isValid(int x, int y) { return (x >= 0 && x < nx && y >= 0 && y < ny); }
inline bool isBomb(int x, int y) { return isValid(x, y) && label(x, y) == Bomb; }
inline bool isEmpty(int x, int y) { return isValid(x, y) && label(x, y) == Empty; }
// ���� �Ҵ� / ����
static void allocateBoard(int w, int h) {
    // ���� �޸� ����
    if (MineMapMask) {
        for (int i = 0; i < ny; i++) {
            delete[] MineMapMask[i];
        }
        delete[] MineMapMask;
        MineMapMask = nullptr;
    }
    if (MineMapLabel) {
        for (int i = 0; i < ny; i++) {
            delete[] MineMapLabel[i];
        }
        delete[] MineMapLabel;
        MineMapLabel = nullptr;
    }

    nx = w; ny = h;
    MineMapMask = new int* [ny];
    MineMapLabel = new int* [ny];
    for (int i = 0; i < ny; i++) {
        MineMapMask[i] = new int[nx];
        MineMapLabel[i] = new int[nx];
    }
}
static int countNbrBombs(int x, int y) {
    int count = 0;
    for (int yy = y - 1; yy <= y + 1; yy++) {
        for (int xx = x - 1; xx <= x + 1; xx++) {
            if (isValid(xx, yy) && label(xx, yy) == Bomb) {
                count++;
            }
        }
    }
    return count;
}
static void init(int total) {
    allocateBoard(10, 10);

    srand((unsigned)time(NULL));
    // �⺻ ����
    for (int r = 0; r < ny; r++) {
        for (int c = 0; c < nx; c++) {
            mask(c, r) = Hide;
            label(c, r) = 0;
        }
    }
    nBomb = total;
    for (int i = 0; i < nBomb; i++) {
        int x, y;
        do {
            x = rand() % nx;
            y = rand() % ny;
        } while (label(x, y) != Empty);
        label(x, y) = Bomb;
    }
    for (int r = 0; r < ny; r++) {
        for (int c = 0; c < nx; c++) {
            if (label(c, r) == Empty) {
                label(c, r) = countNbrBombs(c, r);
            }
        }
    }
}
// �ı�(dig) �Լ� ����
static void dig(int x, int y) {
    if (!isValid(x, y)) return;
    if (mask(x, y) == Open) return;

    mask(x, y) = Open;
    if (label(x, y) == Empty) {
        for (int yy = y - 1; yy <= y + 1; yy++) {
            for (int xx = x - 1; xx <= x + 1; xx++) {
                if (!(xx == x && yy == y)) {
                    dig(xx, yy);
                }
            }
        }
    }
}
static void mark(int x, int y) {
    if (isValid(x, y) && mask(x, y) == Hide) {
        mask(x, y) = Flag;
    }
}
static int getBombCount() {
    int count = 0;
    for (int r = 0; r < ny; r++) {
        for (int c = 0; c < nx; c++) {
            if (mask(c, r) == Flag) {
                count++;
            }
        }
    }
    return count;
}
static void printBoard() {
    system("cls");
    int fCount = getBombCount();
    printf(" �߰�:%2d ��ü:%2d\n\n", fCount, nBomb);
    // �� ��ȣ (1~10) - �ʺ� 3ĭ�� ���
    printf("   ");
    for (int c = 1; c <= nx; c++) {
        printf("%3d", c);
    }
    printf("\n");
    // �� ��: A..J
    for (int r = 0; r < ny; r++) {
        printf("%3c", 'A' + r);  // �� ���� 3ĭ
        for (int c = 0; c < nx; c++) {
            if (mask(c, r) == Hide) {
                printf("%3s", "��");  // 3ĭ ��
            }
            else if (mask(c, r) == Flag) {
                printf("%3s", "��");
            }
            else {
                if (isBomb(c, r))      printf("%3s", "��");
                else if (isEmpty(c, r)) printf("%3s", ".");
                else                   printf("%3d", label(c, r));
            }
        }
        printf("\n");
    }
}
// checkDone
static int checkDone() {
    int count = 0;
    for (int r = 0; r < ny; r++) {
        for (int c = 0; c < nx; c++) {
            if (mask(c, r) != Open) {
                count++;
            }
            else if (isBomb(c, r)) {
                return -1;
            }
        }
    }
    return (count == nBomb) ? 1 : 0;
}
// ��ǥ �Է� (��/��), P ���̸� ���
static bool getPos(int& x, int& y) {
    printf("\n��ǥ �Է� (�� A~J, �� 1~10). ���: 'P'\n");
    printf("��) \"P C 7\", \"B 10\" ��\n�Է� -> ");

    char line[64];
    if (!fgets(line, sizeof(line), stdin)) {
        return false;
    }
    // �빮�ڷ�
    for (char* p = line; *p; p++) {
        if (*p >= 'a' && *p <= 'z') {
            *p = toupper(*p);
        }
    }

    bool isFlag = false;
    char rowCh;
    int colN;
    char t1[16] = { 0 }, t2[16] = { 0 }, t3[16] = { 0 };
    int n = sscanf_s(line, "%s %s %s", t1, (unsigned)_countof(t1),
        t2, (unsigned)_countof(t2),
        t3, (unsigned)_countof(t3));
    if (n == 0) return false;
    if (strcmp(t1, "P") == 0) {
        isFlag = true;
        if (n < 3) {
            printf("�Է� ����.\n");
            return false;
        }
        rowCh = t2[0];    // ��
        colN = atoi(t3); // ��
    }
    else {
        // �ı�
        rowCh = t1[0];
        if (n < 2) {
            printf("�Է� ����.\n");
            return false;
        }
        colN = atoi(t2);
    }
    y = rowCh - 'A'; // A -> 0
    x = colN - 1;    // 1 -> 0
    return isFlag;
}
void playMineSweeper(int total) {
    // ��ŷ ��� (�̹� loadRanking(...) �ߴٰ� ����)
    printRanking();
    printf("\n������ �����Ϸ��� ���͸� ��������...");
    getchar();
    system("cls");
    init(total);
    tStart = clock();
    while (true) {
        printBoard();
        int x, y;
        bool isFlag = getPos(x, y);
        // �����˻�
        if (!isValid(x, y)) {
            printf("�Է� ������ �ùٸ��� �ʽ��ϴ�!\n");
            continue;
        }
        if (isFlag) mark(x, y);
        else dig(x, y);
        int st = checkDone();
        if (st != 0) {
            // ���� ����
            printBoard();
            clock_t tEnd = clock();
            double d = (double)(tEnd - tStart) / CLOCKS_PER_SEC;
            double score = (5000.0 - d * 12.0) + (double)nBomb * 50.0;

            printf("\n�ҿ�ð�: %.2f��\n", d);
            printf("����: %.2f\n", score);
            if (st < 0) {
                printf("����: ���� ����!!!\n\n");
            }
            else {
                printf("����: Ž�� ����!!!\n\n");
                addRanking(nBomb, d, score);
            }
            break;
        }
    }
}